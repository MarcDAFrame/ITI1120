n=int(input("Enter a positive even integer for the size of the list?" ))
