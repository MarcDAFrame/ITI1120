#Course: IT1 1120
#Lab #0
#Frame, Marc
#300022543

print("Printing from a file.")	
